package com.bharath.springdata.transactionmanagement.services;

public interface BankAccountService {
	
	void transfer(int amount);

}
