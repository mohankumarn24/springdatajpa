package com.bharath.springdata.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompositekeyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompositekeyApplication.class, args);
	}

}
