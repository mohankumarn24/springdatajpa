package com.bharath.springdata.patientscheduling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientschedulingApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientschedulingApplication.class, args);
	}

}
