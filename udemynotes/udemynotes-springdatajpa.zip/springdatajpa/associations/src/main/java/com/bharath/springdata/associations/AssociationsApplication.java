package com.bharath.springdata.associations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssociationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssociationsApplication.class, args);
	}

}
