package com.bharath.clinicals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicalsapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
